import { spawn } from "node:child_process";
import { mkdir, stat } from "node:fs/promises";
import { resolve } from "node:path";
import { chromium } from "playwright";

const HOST = "127.0.0.1";
const PORT = "4321";
const ORIGIN = `http://${HOST}:${PORT}`;
const PRINT_URL = `${ORIGIN}/portfolio-print/`;
const OUTPUT = resolve(
  "public/downloads/Daniel-Martinez-Cabeza-de-Vaca-Robotics-Portfolio.pdf"
);

const npmCommand = process.platform === "win32" ? "npm.cmd" : "npm";
let preview;
let browser;

async function waitForPreview(timeoutMs = 45_000) {
  const started = Date.now();
  let lastError;

  while (Date.now() - started < timeoutMs) {
    try {
      const response = await fetch(PRINT_URL, { redirect: "manual" });
      if (response.ok) return;
      lastError = new Error(`Preview returned HTTP ${response.status}`);
    } catch (error) {
      lastError = error;
    }
    await new Promise((resolvePromise) => setTimeout(resolvePromise, 500));
  }

  throw new Error(
    `Astro preview did not become ready within ${timeoutMs} ms. ` +
    `Last error: ${lastError?.message ?? "unknown"}`
  );
}

async function stopPreview() {
  if (!preview || preview.killed) return;

  preview.kill("SIGTERM");

  await Promise.race([
    new Promise((resolvePromise) => preview.once("exit", resolvePromise)),
    new Promise((resolvePromise) => setTimeout(resolvePromise, 4_000)),
  ]);

  if (!preview.killed) preview.kill("SIGKILL");
}

try {
  await mkdir(resolve("public/downloads"), { recursive: true });

  preview = spawn(
    npmCommand,
    ["run", "preview", "--", "--host", HOST, "--port", PORT],
    {
      stdio: ["ignore", "pipe", "pipe"],
      env: { ...process.env, NODE_ENV: "production" },
    }
  );

  preview.stdout.on("data", (chunk) => process.stdout.write(`[preview] ${chunk}`));
  preview.stderr.on("data", (chunk) => process.stderr.write(`[preview] ${chunk}`));

  preview.once("exit", (code) => {
    if (code && code !== 0) {
      console.error(`Astro preview exited unexpectedly with code ${code}.`);
    }
  });

  await waitForPreview();

  browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  await page.emulateMedia({ media: "print" });

  await page.goto(PRINT_URL, {
    waitUntil: "networkidle",
    timeout: 60_000,
  });

  await page.waitForFunction(
    () => document.querySelectorAll(".pdf-page").length === 4,
    undefined,
    { timeout: 30_000 }
  );

  await page.evaluate(async () => {
    await document.fonts.ready;
    await Promise.all(
      Array.from(document.images).map((image) => {
        if (image.complete && image.naturalWidth > 0) return Promise.resolve();
        return new Promise((resolveImage, rejectImage) => {
          image.addEventListener("load", resolveImage, { once: true });
          image.addEventListener(
            "error",
            () => rejectImage(new Error(`Image failed to load: ${image.currentSrc}`)),
            { once: true }
          );
        });
      })
    );
  });

  const dimensions = await page.evaluate(() =>
    Array.from(document.querySelectorAll(".pdf-page")).map((element) => {
      const rect = element.getBoundingClientRect();
      return {
        page: element.getAttribute("data-page"),
        width: rect.width,
        height: rect.height,
        scrollWidth: element.scrollWidth,
        scrollHeight: element.scrollHeight,
      };
    })
  );

  for (const item of dimensions) {
    if (item.scrollWidth > item.width + 2 || item.scrollHeight > item.height + 2) {
      throw new Error(
        `Print page ${item.page ?? "unknown"} overflows: ` +
        `${item.scrollWidth}x${item.scrollHeight} inside ${item.width}x${item.height}.`
      );
    }
  }

  await page.pdf({
    path: OUTPUT,
    printBackground: true,
    preferCSSPageSize: true,
    displayHeaderFooter: false,
    margin: {
      top: "0",
      right: "0",
      bottom: "0",
      left: "0",
    },
  });

  const file = await stat(OUTPUT);
  if (!file.isFile() || file.size < 20_000) {
    throw new Error(`Generated PDF is missing or unexpectedly small: ${file.size} bytes.`);
  }

  console.log(`Generated ${OUTPUT} (${file.size} bytes).`);
} finally {
  if (browser) await browser.close();
  await stopPreview();
}
