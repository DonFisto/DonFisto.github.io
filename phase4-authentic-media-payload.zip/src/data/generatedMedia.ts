import type { GeneratedMediaMetadata } from "./types";

export const mediaMetadata: Record<string, GeneratedMediaMetadata> = {};
